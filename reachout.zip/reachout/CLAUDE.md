# Reachout: project context for Claude Code

Hackathon project (PR 002): turn a template plus event details into a live multilingual outbound
calling campaign for institutions (seminars, clinic reminders, school-parent notices, payment
reminders). Telephony is Exotel (access provided at kickoff).

## Design principles (do not drift from these)

1. Cost is a feature. Target users are schools, clinics and small institutions. The cheapest AI
   minute is the one never run.
2. Hybrid call flow, keypad first:
   greet -> play pre-synthesised message -> collect DTMF (1 confirm, 2 decline, 3 reschedule,
   4 talk to assistant) -> short STT window with a tiny intent classifier only if needed ->
   full LLM + streaming TTS only on escalation or off-script speech.
3. Pre-synthesise templates once per language per campaign. Per-recipient variable slots (name,
   date, venue) are synthesised in a batch before the campaign starts.
4. Self-hosted orchestrator (laptop, small VPS or institution server). No Vapi-style platform fee.
5. Providers are pluggable (STT, TTS, LLM), each tagged with region and what leaves the machine
   (audio, text or nothing). Local models (Piper, Ollama, Whisper) are first-class options,
   mainly for batch pre-synthesis. Do not rely on CPU Whisper for live calls.
6. Contact lists and recordings are personal data: mask phone numbers in API responses, encrypt
   at rest, enforce retention, log access. The UI must show where voice and language processing
   happens for each campaign.
7. Voicemail: no DTMF or speech shortly after the greeting, or a detected beep -> mark voicemail,
   play a short pre-recorded message, schedule a retry. Use Exotel answering-machine detection if
   the plan includes it.
8. Agentic setup is one LLM call per campaign (draft scripts in all languages, DTMF menu, retry
   policy, voicemail text), reviewed by a human before launch. Never one LLM call per recipient
   for deterministic content.

## Current state

- Phase 0 done: FastAPI mock API in `backend/main.py`, vanilla JS dashboard in `frontend/`
  (no build step). Response shapes are the contract real data must fill in, so avoid changing
  them without updating `frontend/app.js`.
- Demo simulator (`DEMO_LIVE`) must be removed or made opt-in once real calls exist.

## Roadmap

- [ ] Phase 1: Exotel skeleton. Outbound call via API to a test number, voicebot/stream applet to
      a WebSocket endpoint (Cloudflare Tunnel for local dev), play a prompt, read a DTMF digit
      back. Do this first: it is the riskiest integration. Check Exotel's audio format and
      whether answering-machine detection is available.
- [ ] Phase 2: DTMF-first call state machine, pre-synthesised templates, voicemail handling,
      persistent storage (SQLite) replacing the in-memory mock data.
- [ ] Phase 3: conversational escalation. Consider Pipecat or LiveKit Agents as the pipeline;
      write only the Exotel transport. Sarvam as the default India-hosted provider, Ollama + Piper
      as the local option.
- [ ] Phase 4: campaign builder (paste event details, pick languages, review drafts, cost estimate
      before launch, launch).
- [ ] Phase 5: dashboard on real data; recording playback behind access control.
- [ ] Phase 6: encryption at rest, retention and auto-delete, access logs, README with the cost
      comparison and architecture.

## Conventions

- Python 3.11+, FastAPI. Keep dependencies minimal; hackathon time is short.
- Frontend: vanilla JS, no build step. Match the existing dark UI tokens in `frontend/styles.css`.
- Secrets (Exotel keys, provider API keys) go in `.env`, never in the repo. Add `.env` to
  `.gitignore` before the first commit.
- Never log full phone numbers or transcripts at INFO level.
- Run the app: `uvicorn backend.main:app --reload`, then open http://localhost:8000.
- When adding a feature, update the roadmap checkboxes above.
