(() => {
  'use strict';

  /* ---------- helpers ---------- */
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const view = $('#view');
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const ICONS = {
    grid: '<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
    phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    cpu: '<rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v4M15 1v4M9 19v4M15 19v4M19 9h4M19 14h4M1 9h4M1 14h4"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    refresh: '<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>',
    chevron: '<path d="m9 18 6-6-6-6"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
    mic: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10v1a7 7 0 0 0 14 0v-1M12 18v4"/>',
    type: '<path d="M4 7V4h16v3M9 20h6M12 4v16"/>',
    lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  };
  const icon = (n, s = 16) => `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n]}</svg>`;

  const ORDER = ['confirmed', 'rescheduled', 'declined', 'voicemail', 'no_answer', 'pending'];
  const OUT = {
    confirmed: 'Confirmed', rescheduled: 'Reschedule', declined: 'Declined',
    voicemail: 'Voicemail', no_answer: 'No answer', pending: 'Queued',
  };
  const KIND = { seminar: 'Seminar', clinic: 'Clinic reminder', school: 'School notice', payment: 'Payment reminder' };
  const CHANNEL = { keypad: 'Keypad', speech: 'Speech', agent: 'Voice agent' };
  const STATUS = { running: 'Running', completed: 'Completed', paused: 'Paused' };

  const nf = new Intl.NumberFormat('en-IN');
  const fmt = {
    int: v => nf.format(Math.round(v)),
    pct: v => `${Math.round(v * 1000) / 10}%`,
    inr: v => (v < 100 ? `₹${v.toFixed(1)}` : `₹${nf.format(Math.round(v))}`),
    inr2: v => `₹${v.toFixed(2)}`,
  };
  const ago = iso => {
    const d = Math.floor((Date.now() - new Date(iso)) / 864e5);
    return d <= 0 ? 'today' : d === 1 ? 'yesterday' : `${d} days ago`;
  };

  async function api(path, opts = {}) {
    const res = await fetch('/api' + path, opts);
    if (!res.ok) {
      const err = new Error(res.status === 404 ? 'Not found' : `Request failed (${res.status})`);
      err.status = res.status;
      throw err;
    }
    return res.json();
  }

  /* ---------- reusable pieces ---------- */
  const pageHead = (title, sub, actions = '') =>
    `<div class="page-head"><div><h1>${title}</h1><p class="sub">${sub}</p></div><div class="actions">${actions}</div></div>`;

  const stat = (label, value, kind, sub, animate = true) =>
    `<div class="card stat"><div class="stat-label">${label}</div>
      <div class="stat-value" ${animate ? `data-count="${value}" data-fmt="${kind}"` : ''}>${fmt[kind](animate ? 0 : value)}</div>
      <div class="stat-sub">${sub}</div></div>`;

  const stack = (counts, total) =>
    `<div class="stack" role="img" aria-label="${ORDER.filter(k => counts[k]).map(k => `${counts[k]} ${OUT[k].toLowerCase()}`).join(', ')}">${
      ORDER.filter(k => counts[k] > 0).map(k =>
        `<span class="seg" style="background:var(--c-${k})" data-w="${(counts[k] / (total || 1) * 100).toFixed(2)}" title="${OUT[k]}: ${counts[k]}"></span>`).join('')}</div>`;

  const legend = (counts, withNumbers) =>
    `<div class="legend">${ORDER.filter(k => counts[k] > 0 || !withNumbers).map(k =>
      `<span class="lg"><i style="background:var(--c-${k})"></i>${OUT[k]}${withNumbers ? ` <b>${fmt.int(counts[k])}</b>` : ''}</span>`).join('')}</div>`;

  const statusPill = s => `<span class="pill status-${s}"><i class="dot"></i>${STATUS[s]}</span>`;
  const outcomePill = r => r.retrying
    ? `<span class="pill retrying"><i class="dot"></i>Retrying</span>`
    : `<span class="pill"><i class="dot" style="background:var(--c-${r.outcome})"></i>${OUT[r.outcome]}</span>`;

  const breakdown = list =>
    `<div class="brow-head"><span></span><span>Outcomes</span><span>Confirmed</span></div>` +
    list.map(g => `<div class="brow">
      <div class="brow-label"><span>${esc(g.key)}</span><small>${fmt.int(g.total)} recipients</small></div>
      ${stack(g.counts, g.total)}
      <div class="brow-val" title="Confirmed, as a share of answered calls">${fmt.pct(g.confirm_rate)}</div></div>`).join('');

  const dailyChart = daily => {
    const max = Math.max(...daily.map(d => d.calls), 1);
    return `<div class="daily">${daily.map(d => `<div class="day" title="${d.label}: ${d.calls} calls, ${d.answered} answered">
      <div class="bar-area"><div class="bar" data-h="${(d.calls / max * 100).toFixed(1)}"><div class="bar-ans" style="height:${d.calls ? d.answered / d.calls * 100 : 0}%"></div></div></div>
      <span class="day-label">${d.label}</span></div>`).join('')}</div>
      <div class="legend chart-legend"><span class="lg"><i style="background:var(--accent)"></i>Answered</span><span class="lg"><i style="background:#262b32"></i>Not answered</span></div>`;
  };

  function campaignTable(list, detailed) {
    if (!list.length) return `<div class="empty"><h2>No campaigns match</h2><p>Try a different search or status.</p></div>`;
    return `<div class="table-wrap"><table class="table"><thead><tr>
      <th>Campaign</th><th>Status</th><th>Languages</th><th class="w-outcomes">Outcomes</th>
      <th class="num">Answer rate</th><th class="num">Cost</th>${detailed ? '<th class="num">Started</th>' : ''}</tr></thead><tbody>
      ${list.map(c => `<tr class="clickable" tabindex="0" data-href="#/campaigns/${esc(c.id)}">
        <td><div class="cell-main">${esc(c.name)}</div><div class="cell-sub">${KIND[c.kind] || c.kind}</div></td>
        <td>${statusPill(c.status)}</td>
        <td class="muted">${c.languages.map(esc).join(', ')}</td>
        <td>${stack(c.totals.counts, c.totals.recipients)}</td>
        <td class="num">${fmt.pct(c.totals.answer_rate)}</td>
        <td class="num">${fmt.inr(c.totals.cost_inr)}</td>
        ${detailed ? `<td class="num muted">${ago(c.started_at)}</td>` : ''}</tr>`).join('')}
      </tbody></table></div>`;
  }

  /* ---------- motion helpers ---------- */
  function grow(root, animate) {
    $$('[data-w],[data-h]', root).forEach(el => {
      const prop = el.dataset.w !== undefined ? 'width' : 'height';
      const val = (el.dataset.w ?? el.dataset.h) + '%';
      if (animate && !reduceMotion) {
        el.style[prop] = '0';
        requestAnimationFrame(() => requestAnimationFrame(() => { el.style[prop] = val; }));
      } else el.style[prop] = val;
    });
  }

  function countUp(root) {
    $$('[data-count]', root).forEach(el => {
      const to = parseFloat(el.dataset.count), f = fmt[el.dataset.fmt || 'int'];
      if (reduceMotion) { el.textContent = f(to); return; }
      const t0 = performance.now(), dur = 800;
      const step = t => {
        const p = Math.min(1, (t - t0) / dur);
        el.textContent = f(to * (1 - Math.pow(1 - p, 3)));
        if (p < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    });
  }

  /* ---------- overlays ---------- */
  function toast(msg, kind = 'ok') {
    const el = document.createElement('div');
    el.className = `toast ${kind}`;
    el.innerHTML = `${icon(kind === 'error' ? 'x' : kind === 'info' ? 'info' : 'check')}<span>${esc(msg)}</span>`;
    $('#toasts').appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 250); }, 3200);
  }

  function modal({ title, body, confirmLabel, onConfirm }) {
    const ov = document.createElement('div');
    ov.className = 'overlay';
    ov.innerHTML = `<div class="modal" role="dialog" aria-modal="true" aria-labelledby="m-title">
      <h2 id="m-title">${title}</h2><div class="modal-body">${body}</div>
      <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" data-ok>${confirmLabel}</button></div></div>`;
    const prev = document.activeElement;
    document.body.appendChild(ov);
    void ov.offsetWidth;
    ov.classList.add('open');
    const onKey = e => { if (e.key === 'Escape') close(); };
    const close = () => {
      ov.classList.remove('open');
      document.removeEventListener('keydown', onKey);
      setTimeout(() => { ov.remove(); if (prev && prev.focus) prev.focus(); }, reduceMotion ? 0 : 180);
    };
    document.addEventListener('keydown', onKey);
    ov.addEventListener('mousedown', e => { if (e.target === ov) close(); });
    $('[data-x]', ov).onclick = close;
    const ok = $('[data-ok]', ov);
    ok.focus();
    ok.onclick = async () => {
      ok.disabled = true;
      ok.innerHTML = '<span class="spinner"></span>Working';
      try { await onConfirm(); close(); }
      catch (e) { ok.disabled = false; ok.textContent = confirmLabel; toast(e.message || 'Something went wrong', 'error'); }
    };
  }

  /* ---------- router ---------- */
  let token = 0, pollTimer = null, skelTimer = null;
  const stopPoll = () => { clearInterval(pollTimer); pollTimer = null; };

  function setCrumbs(parts) {
    $('#crumbs').innerHTML = parts.map(([label, href], i) => {
      const last = i === parts.length - 1;
      return (i ? icon('chevron', 14) : '') + (last ? `<span class="cur">${esc(label)}</span>` : `<a href="${href}">${esc(label)}</a>`);
    }).join('');
  }

  function setNav(hash) {
    $$('[data-nav]').forEach(a => a.classList.toggle('active', hash.startsWith('#/' + a.dataset.nav)));
  }

  function mount(html) {
    clearTimeout(skelTimer);
    view.innerHTML = html;
    view.classList.remove('enter');
    void view.offsetWidth;
    view.classList.add('enter');
    window.scrollTo(0, 0);
  }

  function showSkeleton() {
    clearTimeout(skelTimer);
    skelTimer = setTimeout(() => {
      view.classList.remove('enter');
      view.innerHTML = `<div class="skel skel-head"></div><div class="grid-4">${'<div class="skel skel-card"></div>'.repeat(4)}</div><div class="skel skel-block"></div>`;
    }, 140);
  }

  function showError(e) {
    clearTimeout(skelTimer);
    const missing = e.status === 404;
    view.innerHTML = missing
      ? `<div class="empty"><h2>Campaign not found</h2><p>It may have been removed.</p><p style="margin-top:14px"><a class="btn" href="#/campaigns">Back to campaigns</a></p></div>`
      : `<div class="empty"><h2>Can't reach the server</h2><p>Start the backend from the project folder, then try again.</p>
         <code>uvicorn backend.main:app --reload</code><p><button class="btn" id="retry-load">Try again</button></p></div>`;
    const b = $('#retry-load');
    if (b) b.onclick = route;
  }

  const routes = [
    [/^#\/overview$/, Overview],
    [/^#\/campaigns$/, Campaigns],
    [/^#\/campaigns\/([\w-]+)$/, CampaignDetail],
  ];

  async function route() {
    if (!location.hash) { location.hash = '#/overview'; return; }
    const t = ++token;
    stopPoll();
    const hash = location.hash;
    setNav(hash);
    for (const [re, fn] of routes) {
      const m = hash.match(re);
      if (!m) continue;
      showSkeleton();
      try { await fn(t, ...m.slice(1)); }
      catch (e) { if (t === token) showError(e); }
      return;
    }
    location.hash = '#/overview';
  }

  /* ---------- pages ---------- */
  async function Overview(t) {
    const d = await api('/overview');
    if (t !== token) return;
    const s = d.totals;
    setCrumbs([['Overview']]);
    mount(`
      ${pageHead('Overview', 'How your calling campaigns are performing.')}
      <section class="grid-4">
        ${stat('Calls placed', s.calls_placed, 'int', `to ${fmt.int(s.contacted)} of ${fmt.int(s.recipients)} recipients`)}
        ${stat('Answer rate', s.answer_rate, 'pct', `${fmt.int(s.answered)} calls answered`)}
        ${stat('Confirmed', s.counts.confirmed, 'int', `${fmt.pct(s.confirm_rate)} of answered calls`)}
        ${stat('Estimated cost', s.cost_inr, 'inr', `${fmt.inr2(s.cost_inr / Math.max(s.calls_placed, 1))} per call`)}
      </section>
      <section class="grid-2">
        <div class="card"><div class="card-head"><h2>Calls per day</h2></div>${dailyChart(d.daily)}</div>
        <div class="card"><div class="card-head"><h2>By language</h2></div>${breakdown(d.by_language)}</div>
      </section>
      <section class="card">
        <div class="card-head"><h2>Campaigns</h2><a href="#/campaigns">View all</a></div>
        <div style="padding:12px 16px;border-bottom:1px solid var(--line)">${legend(s.counts, true)}</div>
        ${campaignTable(d.campaigns, false)}
      </section>`);
    grow(view, true);
    countUp(view);
  }

  async function Campaigns(t) {
    const list = (await api('/campaigns')).campaigns;
    if (t !== token) return;
    setCrumbs([['Campaigns']]);
    mount(`
      ${pageHead('Campaigns', 'Every invitation, reminder and notice you have sent.')}
      <div class="toolbar">
        <div class="search">${icon('search')}<input class="input" id="c-q" placeholder="Search campaigns" aria-label="Search campaigns"></div>
        <div class="seg-ctl" id="c-status">${[['all', 'All'], ['running', 'Running'], ['paused', 'Paused'], ['completed', 'Completed']]
          .map(([v, l], i) => `<button data-st="${v}" class="${i ? '' : 'on'}">${l}</button>`).join('')}</div>
      </div>
      <div class="card" id="c-table"></div>`);
    let q = '', st = 'all';
    const paint = animate => {
      const rows = list.filter(c => (st === 'all' || c.status === st) && c.name.toLowerCase().includes(q));
      const box = $('#c-table');
      box.innerHTML = campaignTable(rows, true);
      grow(box, animate);
    };
    $('#c-q').addEventListener('input', e => { q = e.target.value.trim().toLowerCase(); paint(false); });
    $('#c-status').addEventListener('click', e => {
      const b = e.target.closest('button');
      if (!b) return;
      st = b.dataset.st;
      $$('#c-status button').forEach(x => x.classList.toggle('on', x === b));
      paint(false);
    });
    paint(true);
  }

  async function CampaignDetail(t, id) {
    let d = await api(`/campaigns/${id}`);
    if (t !== token) return;
    const f = { q: '', outcome: 'all', language: 'all', segment: 'all', limit: 50 };
    setCrumbs([['Campaigns', '#/campaigns'], [d.name]]);

    const opts = arr => arr.map(v => `<option value="${esc(v)}">${esc(v)}</option>`).join('');
    mount(`
      <div id="d-head"></div>
      <section class="grid-4" id="d-stats"></section>
      <section class="grid-2 even">
        <div class="card" id="d-lang"></div><div class="card" id="d-seg"></div>
      </section>
      <section class="card handling" id="d-handling"></section>
      <section class="card">
        <div class="card-head"><h2>Recipients</h2>
          <div class="filters">
            <div class="search">${icon('search')}<input class="input" id="f-q" placeholder="Search by name" aria-label="Search recipients"></div>
            <select class="select" id="f-outcome" aria-label="Filter by outcome">
              <option value="all">All outcomes</option><option value="nonresp">Non-responders</option>
              ${ORDER.map(k => `<option value="${k}">${OUT[k]}</option>`).join('')}</select>
            <select class="select" id="f-language" aria-label="Filter by language"><option value="all">All languages</option>${opts(d.languages)}</select>
            <select class="select" id="f-segment" aria-label="Filter by segment"><option value="all">All segments</option>${opts(d.segments)}</select>
          </div></div>
        <div id="d-table"></div>
      </section>`);

    const paintHead = () => {
      const n = d.totals.retryable, busy = d.totals.retrying > 0;
      $('#d-head').innerHTML = `<div class="page-head"><div>
          <h1>${esc(d.name)}</h1>
          <div class="meta">${statusPill(d.status)}<span class="chip">${KIND[d.kind] || d.kind}</span>
            ${d.languages.map(l => `<span class="chip">${esc(l)}</span>`).join('')}
            <span class="muted">Started ${ago(d.started_at)}</span></div></div>
        <div class="actions"><button class="btn primary" id="retry-btn" ${n === 0 || busy ? 'disabled' : ''}
          title="${n === 0 && !busy ? 'No one is waiting for a retry' : ''}">
          ${busy ? '<span class="spinner"></span>' : icon('refresh')}
          ${busy ? `Retrying ${fmt.int(d.totals.retrying)}` : 'Retry non-responders'}
          ${!busy && n > 0 ? `<span class="count">${fmt.int(n)}</span>` : ''}</button></div></div>`;
      $('#retry-btn').onclick = openRetry;
    };

    const paintStats = animate => {
      const s = d.totals;
      $('#d-stats').innerHTML =
        stat('Calls placed', s.calls_placed, 'int', `to ${fmt.int(s.contacted)} of ${fmt.int(s.recipients)} recipients`, animate) +
        stat('Answer rate', s.answer_rate, 'pct', `${fmt.int(s.answered)} calls answered`, animate) +
        stat('Confirmed', s.counts.confirmed, 'int', `${fmt.pct(s.confirm_rate)} of answered calls`, animate) +
        stat('Estimated cost', s.cost_inr, 'inr', `${fmt.inr2(s.cost_inr / Math.max(s.calls_placed, 1))} per call`, animate);
      if (animate) countUp($('#d-stats'));
    };

    const paintBreakdowns = animate => {
      $('#d-lang').innerHTML = `<div class="card-head"><h2>Outcomes by language</h2></div>${breakdown(d.by_language)}`;
      $('#d-seg').innerHTML = `<div class="card-head"><h2>Outcomes by audience segment</h2></div>${breakdown(d.by_segment)}`;
      grow($('#d-lang'), animate);
      grow($('#d-seg'), animate);
    };

    const paintHandling = () => {
      const h = d.handling;
      const item = (ic, label, x) => `<div class="h-item">${icon(ic, 18)}<div><div class="h-label">${label}</div><div class="h-main">${esc(x.provider)}</div><div class="h-note">${esc(x.note)}</div></div></div>`;
      $('#d-handling').innerHTML = `<div class="card-head"><h2>Where your data is processed</h2></div>
        ${item('mic', 'Voice', h.audio)}${item('type', 'Language', h.text)}${item('lock', 'Recordings', h.recordings)}`;
    };

    const paintTable = () => {
      const q = f.q.toLowerCase();
      const rows = d.recipients.filter(r =>
        (f.outcome === 'all' || (f.outcome === 'nonresp' ? ['voicemail', 'no_answer'].includes(r.outcome) : r.outcome === f.outcome)) &&
        (f.language === 'all' || r.language === f.language) &&
        (f.segment === 'all' || r.segment === f.segment) &&
        (!q || r.name.toLowerCase().includes(q)));
      const shown = rows.slice(0, f.limit);
      $('#d-table').innerHTML = rows.length ? `<div class="table-wrap"><table class="table"><thead><tr>
        <th>Name</th><th>Phone</th><th>Language</th><th>Segment</th><th>Outcome</th><th>Replied by</th><th class="num">Attempts</th></tr></thead><tbody>
        ${shown.map(r => `<tr><td>${esc(r.name)}</td><td class="mono muted">${esc(r.phone)}</td><td>${esc(r.language)}</td>
          <td class="muted">${esc(r.segment)}</td><td>${outcomePill(r)}</td>
          <td class="muted">${r.channel ? CHANNEL[r.channel] : '–'}</td><td class="num">${r.attempts}</td></tr>`).join('')}
        </tbody></table></div>
        <div class="table-foot"><span>Showing ${fmt.int(shown.length)} of ${fmt.int(rows.length)}</span>
          ${rows.length > shown.length ? '<button class="btn" id="more">Show 50 more</button>' : ''}</div>`
        : `<div class="empty"><h2>No recipients match</h2><p>Try clearing a filter.</p></div>`;
      const more = $('#more');
      if (more) more.onclick = () => { f.limit += 50; paintTable(); };
    };

    const paintAll = animate => { paintHead(); paintStats(animate); paintBreakdowns(animate); paintTable(); };

    function openRetry() {
      const c = d.totals.counts;
      modal({
        title: 'Retry non-responders',
        body: `Recipients who reached voicemail or did not pick up will be called again with the same script, in their own language.
          <dl class="facts"><div><dt>Recipients</dt><dd>${fmt.int(d.totals.retryable)}</dd></div>
          <div><dt>Made up of</dt><dd>${fmt.int(c.voicemail)} voicemail, ${fmt.int(c.no_answer)} no answer</dd></div>
          <div><dt>Estimated cost</dt><dd>${fmt.inr2(d.retry_estimate_inr)}</dd></div></dl>`,
        confirmLabel: `Call ${fmt.int(d.totals.retryable)} again`,
        onConfirm: async () => {
          const res = await api(`/campaigns/${id}/retry`, { method: 'POST' });
          toast(`Retrying ${fmt.int(res.queued)} recipients`);
          d = await api(`/campaigns/${id}`);
          if (t !== token) return;
          paintAll(false);
          startPoll();
        },
      });
    }

    function startPoll() {
      stopPoll();
      pollTimer = setInterval(async () => {
        if (t !== token) return stopPoll();
        try {
          const nd = await api(`/campaigns/${id}`);
          if (t !== token) return;
          d = nd;
          paintAll(false);
          if (d.status !== 'running' && d.totals.retrying === 0) stopPoll();
        } catch { /* keep the last good view; try again next tick */ }
      }, 2500);
    }

    paintHead(); paintStats(true); paintBreakdowns(true); paintHandling(); paintTable();
    $('#f-q').addEventListener('input', e => { f.q = e.target.value.trim(); f.limit = 50; paintTable(); });
    ['outcome', 'language', 'segment'].forEach(k =>
      $('#f-' + k).addEventListener('change', e => { f[k] = e.target.value; f.limit = 50; paintTable(); }));
    if (d.status === 'running' || d.totals.retrying > 0) startPoll();
  }

  /* ---------- boot ---------- */
  $$('[data-icon]').forEach(el => { el.outerHTML = icon(el.dataset.icon); });
  $('#new-campaign').addEventListener('click', () => toast('The campaign builder is the next piece to build.', 'info'));
  view.addEventListener('click', e => {
    const tr = e.target.closest('tr[data-href]');
    if (tr) location.hash = tr.dataset.href;
  });
  view.addEventListener('keydown', e => {
    const tr = e.target.closest('tr[data-href]');
    if (tr && e.key === 'Enter') location.hash = tr.dataset.href;
  });
  addEventListener('hashchange', route);
  route();
})();
